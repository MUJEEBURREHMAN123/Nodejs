 /*
 const fs = require('fs');

fs.writeFileSync("Hi.txt","This is Node js Course 1");

*/



/*
const readline = require("readline");

const r1 = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

r1.question("What is your name? ", function(answer) {
    console.log("My name is", answer);
    
});
*/


const prompt = require("prompt-sync")();

const input = prompt("What is Your name");

console.log(`oh,so your name is ${input}`);
